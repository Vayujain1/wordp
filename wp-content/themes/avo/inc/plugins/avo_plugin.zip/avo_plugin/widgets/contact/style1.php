		<div class="avo-contact-shortcode <?php echo 'contact-'.$style; ?> "><?php echo $shortcode; ?></div>
