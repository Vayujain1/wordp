<div class="avo-image avo-tooltip style-1">
	    <div class="img sizxl mb-30" data-tooltip-tit="<?php echo  $settings['title']; ?>" data-tooltip-sub="<?php echo  $settings['subtitle']; ?>">
	        <img src="<?php echo esc_url ( $settings['image']['url']); ?>" alt="" class="imago wow">
	    </div> 
	    <div class="div-tooltip-tit"><?php echo  $settings['title']; ?></div>
</div>