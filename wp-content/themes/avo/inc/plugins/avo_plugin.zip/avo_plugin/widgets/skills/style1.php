<div class="skills style-1 progress-circular-layout circle-light <?php echo 'mode-'.$settings['avo_mode'];?>">
	<div class="item">
		<div class="skill progress-circular">
			<div ><input type="text" class="knob knob-percent dial custom-font" value="0" data-max="100" data-rel="<?php echo  $settings['progress_num']; ?>" data-linecap="solid" data-width="<?php echo  $settings['progress_width']; ?>" data-height="<?php echo  $settings['progress_height']; ?>" data-bgcolor="<?php echo  $settings['progress_bgcolor']; ?>" data-fgcolor="<?php echo  $settings['progress_fgcolor']; ?>" data-thickness="<?php echo  $settings['progress_thickness']; ?>" data-readonly="true" data-speed="<?php echo  $settings['progress_speed']; ?>" data-steps="<?php echo  $settings['progress_steps']; ?>" disabled></div>
		</div>
	    <div class="cont">
	        <span><?php echo  $settings['progress_title']; ?></span>
	        <h6><?php echo  $settings['progress_subtitle']; ?></h6>
	    </div>
	</div>
</div>
